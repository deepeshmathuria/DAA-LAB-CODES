#include<stdio.h>
#include"methods.h"
void main(){
int V;
printf("Enter the no. of vertices:");
scanf("%d",&V);
generateGraph(V);
}